//! Instance admission for physical persistence, including queued and canceled jobs.
#[cfg(test)]
use super::physical_tests::Gate;
use std::sync::Arc;
#[cfg(test)]
use std::sync::{
    atomic::{AtomicBool, AtomicUsize, Ordering},
    Mutex,
};
use tokio::sync::{OwnedSemaphorePermit, Semaphore};

const PHYSICAL_SLOTS: usize = 1;

pub(super) struct Worker {
    slot: Arc<Semaphore>,
    #[cfg(test)]
    pub(super) probe: Arc<Probe>,
}

pub(super) struct Interrupted;

// This wrapper names the input whose destruction stays inside Job's admission.
pub(super) struct Input<T> {
    value: T,
    #[cfg(test)]
    gate: Option<Arc<Gate>>,
}
impl<T> Input<T> {
    pub(super) fn get(&self) -> &T {
        &self.value
    }
}
#[cfg(test)]
impl<T> Drop for Input<T> {
    fn drop(&mut self) {
        // The real value field is dropped after this destructor returns.
        if let Some(gate) = &self.gate {
            gate.enter();
        }
    }
}

impl Worker {
    pub(super) fn new() -> Self {
        Self {
            slot: Arc::new(Semaphore::new(PHYSICAL_SLOTS)),
            #[cfg(test)]
            probe: Arc::new(Probe::default()),
        }
    }

    pub(super) async fn admit(&self) -> Result<OwnedSemaphorePermit, Interrupted> {
        self.slot
            .clone()
            .acquire_owned()
            .await
            .map_err(|_| Interrupted)
    }

    pub(super) fn input<T>(&self, value: T) -> Input<T> {
        Input {
            value,
            #[cfg(test)]
            gate: self.probe.input_drop.lock().unwrap().take(),
        }
    }

    pub(super) async fn run<F, R>(
        &self,
        permit: OwnedSemaphorePermit,
        operation: F,
    ) -> Result<R, Interrupted>
    where
        F: FnMut() -> R + Send + 'static,
        R: Send + 'static,
    {
        #[cfg(test)]
        self.probe.submitted.fetch_add(1, Ordering::SeqCst);
        let job = Job {
            operation,
            #[cfg(test)]
            completion: Completion(self.probe.clone()),
            _permit: permit,
        };
        let handle = tokio::task::spawn_blocking(move || job.run());
        #[cfg(test)]
        if self.probe.abort_queued.swap(false, Ordering::SeqCst) {
            handle.abort();
        }
        match handle.await {
            Ok(output) => Ok(output),
            Err(error) => {
                if error.is_panic() {
                    // Payloads can contain secrets or have panicking destructors.
                    // As in SDK lifecycle supervision, do not inspect or drop them.
                    std::mem::forget(error.into_panic());
                }
                Err(Interrupted)
            }
        }
    }

    #[cfg(test)]
    pub(super) fn close(&self) {
        self.slot.close();
    }
}

// Rust drops fields in declaration order. The operation (including captured
// input and adapter state) is destroyed before admission, on return or unwind.
// worker_input_drop_keeps_slot exercises this ordering at physical cleanup.
struct Job<F> {
    operation: F,
    #[cfg(test)]
    completion: Completion,
    _permit: OwnedSemaphorePermit,
}

impl<F> Job<F> {
    fn run<R>(mut self) -> R
    where
        F: FnMut() -> R,
    {
        #[cfg(test)]
        {
            let probe = &self.completion.0;
            probe.started.fetch_add(1, Ordering::SeqCst);
            let gate = probe.before.lock().unwrap().take();
            if let Some(gate) = gate {
                gate.enter();
            }
            if probe.payload_before.swap(false, Ordering::SeqCst) {
                std::panic::panic_any(Payload);
            }
            assert!(
                !probe.panic_before.swap(false, Ordering::SeqCst),
                "physical worker pre-effect fault"
            );
        }
        let output = (self.operation)();
        #[cfg(test)]
        {
            let probe = &self.completion.0;
            let gate = probe.after.lock().unwrap().take();
            if let Some(gate) = gate {
                gate.enter();
            }
            assert!(
                !probe.panic_after.swap(false, Ordering::SeqCst),
                "physical worker post-effect fault"
            );
        }
        drop(self);
        output
    }
}

#[cfg(test)]
#[derive(Default)]
pub(super) struct Probe {
    pub(super) submitted: AtomicUsize,
    pub(super) started: AtomicUsize,
    pub(super) cleaned: AtomicUsize,
    pub(super) before: Mutex<Option<Arc<Gate>>>,
    pub(super) after: Mutex<Option<Arc<Gate>>>,
    pub(super) input_drop: Mutex<Option<Arc<Gate>>>,
    pub(super) abort_queued: AtomicBool,
    pub(super) payload_before: AtomicBool,
    pub(super) panic_before: AtomicBool,
    pub(super) panic_after: AtomicBool,
}
#[cfg(test)]
struct Completion(Arc<Probe>);
#[cfg(test)]
impl Drop for Completion {
    fn drop(&mut self) {
        self.0.cleaned.fetch_add(1, Ordering::SeqCst);
    }
}

#[cfg(test)]
struct Payload;
#[cfg(test)]
impl Drop for Payload {
    fn drop(&mut self) {
        panic!("faulting panic payload destructor");
    }
}
