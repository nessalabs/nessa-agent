use std::future::Future;
use std::io::{Read, Seek, SeekFrom, Write};

use uuid::Uuid;

use super::FileRecords;
use crate::mcp_authorization::application::{AuthorizationRecords, RecordFailure, TokenMaterial};
use crate::mcp_authorization::domain::{Deletion, Publication, ServerAuth};
use std::sync::Arc;

fn secret() -> TokenMaterial {
    TokenMaterial {
        access_token: "sekret-token".into(),
        refresh_token: Some("refresh-sekret".into()),
        generation: 3,
    }
}

fn records() -> (FileRecords, std::path::PathBuf) {
    let directory = std::env::temp_dir().join(format!("nessa-mcp-auth-{}", Uuid::new_v4()));
    (FileRecords::new(&directory), directory)
}

fn contains_token(directory: &std::path::Path, token: &str) -> bool {
    let mut pending = vec![directory.to_path_buf()];
    while let Some(path) = pending.pop() {
        let Ok(entries) = std::fs::read_dir(&path) else {
            continue;
        };
        for entry in entries.flatten() {
            let path = entry.path();
            if path.is_dir() {
                pending.push(path);
                continue;
            }
            let Ok(bytes) = std::fs::read(&path) else {
                continue;
            };
            if bytes
                .windows(token.len())
                .any(|window| window == token.as_bytes())
            {
                return true;
            }
        }
    }
    false
}

#[test]
fn record_store_keeps_current_thread_heartbeat_running() {
    let (mut records, directory) = records();
    super::super::physical_tests::heartbeat(|gate| async move {
        Arc::get_mut(&mut records.state).unwrap().gate = Some(gate);
        let server = Uuid::new_v4();
        records
            .store(&ServerAuth::consent_needed(
                server,
                "docs",
                "https://mcp.example/mcp",
            ))
            .await
            .unwrap();
        Arc::get_mut(&mut records.state).unwrap().gate = None;
        assert!(records.load(server).await.unwrap().is_some());
    });
    let _ = std::fs::remove_dir_all(directory);
}

#[test]
fn secret_store_keeps_current_thread_heartbeat_running() {
    let (mut records, directory) = records();
    super::super::physical_tests::heartbeat(|gate| async move {
        Arc::get_mut(&mut records.state).unwrap().gate = Some(gate);
        let server = Uuid::new_v4();
        assert_eq!(
            records.store_secret(server, &secret()).await,
            Ok(Publication::Acknowledged)
        );
        Arc::get_mut(&mut records.state).unwrap().gate = None;
        assert!(records.load_secret(server).await.unwrap() == Some(secret()));
    });
    let _ = std::fs::remove_dir_all(directory);
}

#[tokio::test]
async fn a_sealed_file_round_trips_and_never_stores_the_token_in_the_clear() {
    let (records, directory) = records();
    assert!(records.writer_available());
    let server = Uuid::new_v4();
    let secret = secret();
    assert_eq!(
        records.store_secret(server, &secret).await,
        Ok(Publication::Acknowledged)
    );
    let loaded = records.load_secret(server).await.unwrap().unwrap();
    assert_eq!(loaded.access_token, secret.access_token);
    assert_eq!(loaded.refresh_token, secret.refresh_token);
    assert_eq!(loaded.generation, secret.generation);
    assert!(!contains_token(&directory, "sekret-token"));
    assert!(!contains_token(&directory, "refresh-sekret"));
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        for name in ["key", &format!("{server}.seal")] {
            let mode = std::fs::metadata(directory.join("secrets").join(name))
                .unwrap()
                .permissions()
                .mode();
            assert_eq!(mode & 0o077, 0, "{name} is not user-only: {mode:o}");
        }
    }
    let facts = ServerAuth::consent_needed(server, "docs", "https://mcp.example/mcp");
    records.store(&facts).await.unwrap();
    let record_path = directory.join(format!("{server}.json"));
    let record = std::fs::read(&record_path).unwrap();
    assert!(!record
        .windows(b"sekret-token".len())
        .any(|window| window == b"sekret-token"));
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        let mode = std::fs::metadata(&record_path)
            .unwrap()
            .permissions()
            .mode();
        assert_eq!(mode & 0o077, 0, "the record is not user-only: {mode:o}");
    }
    assert_eq!(records.delete_secret(server).await, Ok(Deletion::Deleted));
    assert_eq!(records.load_secret(server).await, Ok(None));
    let _ = std::fs::remove_dir_all(&directory);
}

#[tokio::test]
async fn a_tampered_seal_is_unavailable_and_not_a_token() {
    let (records, directory) = records();
    let server = Uuid::new_v4();
    records.store_secret(server, &secret()).await.unwrap();
    let path = directory.join("secrets").join(format!("{server}.seal"));
    let mut file =
        nessa_local_storage::open(&path, nessa_local_storage::OpenMode::ReadWrite).unwrap();
    let mut byte = [0_u8; 1];
    file.read_exact(&mut byte).unwrap();
    byte[0] ^= 0xff;
    file.seek(SeekFrom::Start(0)).unwrap();
    file.write_all(&byte).unwrap();
    assert_eq!(
        records.load_secret(server).await,
        Err(RecordFailure::Unavailable)
    );
    let _ = std::fs::remove_dir_all(&directory);
}
#[test]
fn record_load_keeps_current_thread_heartbeat_running() {
    let (mut records, directory) = records();
    super::super::physical_tests::heartbeat(|gate| async move {
        let server = Uuid::new_v4();
        records
            .store(&ServerAuth::consent_needed(
                server,
                "docs",
                "https://mcp.example/mcp",
            ))
            .await
            .unwrap();
        Arc::get_mut(&mut records.state).unwrap().gate = Some(gate);
        assert!(records.load(server).await.unwrap().is_some());
    });
    let _ = std::fs::remove_dir_all(directory);
}

#[test]
fn secret_load_keeps_current_thread_heartbeat_running() {
    let (mut records, directory) = records();
    super::super::physical_tests::heartbeat(|gate| async move {
        let server = Uuid::new_v4();
        records.store_secret(server, &secret()).await.unwrap();
        Arc::get_mut(&mut records.state).unwrap().gate = Some(gate);
        assert!(records.load_secret(server).await.unwrap() == Some(secret()));
    });
    let _ = std::fs::remove_dir_all(directory);
}

#[test]
fn secret_delete_keeps_current_thread_heartbeat_running() {
    let (mut records, directory) = records();
    super::super::physical_tests::heartbeat(|gate| async move {
        let server = Uuid::new_v4();
        records.store_secret(server, &secret()).await.unwrap();
        Arc::get_mut(&mut records.state).unwrap().gate = Some(gate);
        assert_eq!(records.delete_secret(server).await, Ok(Deletion::Deleted));
    });
    let _ = std::fs::remove_dir_all(directory);
}

#[tokio::test]
async fn canceled_secret_store_excludes_delete_and_load() {
    let (records, directory) = records();
    let records = Arc::new(records);
    let server = Uuid::new_v4();
    let probe = records.worker.probe.clone();
    let (gate, watchdog) = super::super::physical_tests::hold(probe.clone());
    *probe.before.lock().unwrap() = Some(gate);
    let first = records.clone();
    let caller = tokio::spawn(async move { first.store_secret(server, &secret()).await });
    super::super::physical_tests::reached(&probe.started, 1).await;
    caller.abort();
    assert!(caller.await.unwrap_err().is_cancelled());
    let waiting = records.clone();
    let canceled = tokio::spawn(async move { waiting.load_secret(server).await });
    tokio::task::yield_now().await;
    canceled.abort();
    assert!(canceled.await.unwrap_err().is_cancelled());
    let later = records.clone();
    let deletion = tokio::spawn(async move { later.delete_secret(server).await });
    let recovery = records.clone();
    let load = tokio::spawn(async move { recovery.load_secret(server).await });
    assert_eq!(deletion.await.unwrap(), Ok(Deletion::Deleted));
    assert!(load.await.unwrap().unwrap().is_none());
    assert_eq!(watchdog.join().unwrap(), (1, 1, 0));
    assert!(records.load_secret(server).await.unwrap().is_none());
    let _ = std::fs::remove_dir_all(directory);
}

#[tokio::test]
async fn canceled_delete_excludes_replacement() {
    let (records, directory) = records();
    let records = Arc::new(records);
    let server = Uuid::new_v4();
    records.store_secret(server, &secret()).await.unwrap();
    let probe = records.worker.probe.clone();
    let (gate, watchdog) = super::super::physical_tests::hold(probe.clone());
    *probe.before.lock().unwrap() = Some(gate);
    let first = records.clone();
    let caller = tokio::spawn(async move { first.delete_secret(server).await });
    super::super::physical_tests::reached(&probe.started, 2).await;
    caller.abort();
    let _ = caller.await;
    let mut replacement = secret();
    replacement.access_token = "replacement-token".into();
    assert_eq!(
        records.store_secret(server, &replacement).await,
        Ok(Publication::Acknowledged)
    );
    assert_eq!(watchdog.join().unwrap(), (2, 2, 1));
    assert!(records.load_secret(server).await.unwrap() == Some(replacement));
    let _ = std::fs::remove_dir_all(directory);
}

#[tokio::test]
async fn worker_input_drop_keeps_slot() {
    let (records, directory) = records();
    let records = Arc::new(records);
    let server = Uuid::new_v4();
    let probe = records.worker.probe.clone();
    let (gate, watchdog) = super::super::physical_tests::hold(probe.clone());
    *probe.input_drop.lock().unwrap() = Some(gate);
    let first = records.clone();
    let caller = tokio::spawn(async move { first.store_secret(server, &secret()).await });
    super::super::physical_tests::reached(&probe.started, 1).await;
    caller.abort();
    let _ = caller.await;
    assert_eq!(records.delete_secret(server).await, Ok(Deletion::Deleted));
    assert_eq!(watchdog.join().unwrap(), (1, 1, 0));
    let _ = std::fs::remove_dir_all(directory);
}

#[tokio::test]
async fn interrupted_record_operations_are_unavailable_or_unknown() {
    use std::sync::atomic::Ordering;
    let (records, directory) = records();
    let server = Uuid::new_v4();
    let auth = ServerAuth::consent_needed(server, "docs", "https://mcp.example/mcp");
    records
        .worker
        .probe
        .panic_before
        .store(true, Ordering::SeqCst);
    assert!(matches!(
        records.load(server).await,
        Err(RecordFailure::Unavailable)
    ));
    records
        .worker
        .probe
        .panic_before
        .store(true, Ordering::SeqCst);
    assert!(records.load_secret(server).await == Err(RecordFailure::Unavailable));
    records
        .worker
        .probe
        .panic_after
        .store(true, Ordering::SeqCst);
    assert_eq!(records.store(&auth).await, Err(RecordFailure::Unavailable));
    assert!(records.load(server).await.unwrap().is_some());
    records
        .worker
        .probe
        .panic_after
        .store(true, Ordering::SeqCst);
    assert_eq!(
        records.store_secret(server, &secret()).await,
        Ok(Publication::Unknown)
    );
    assert!(records.load_secret(server).await.unwrap() == Some(secret()));
    records
        .worker
        .probe
        .panic_after
        .store(true, Ordering::SeqCst);
    assert_eq!(records.delete_secret(server).await, Ok(Deletion::Unknown));
    assert!(records.load_secret(server).await.unwrap().is_none());
    records.worker.close();
    assert_eq!(
        records.delete_secret(server).await,
        Err(RecordFailure::Unavailable)
    );
    assert_eq!(
        records.store_secret(server, &secret()).await,
        Err(RecordFailure::Unavailable)
    );
    assert!(records.load_secret(server).await == Err(RecordFailure::Unavailable));
    assert_eq!(records.store(&auth).await, Err(RecordFailure::Unavailable));
    assert!(matches!(
        records.load(server).await,
        Err(RecordFailure::Unavailable)
    ));
    let _ = std::fs::remove_dir_all(directory);
}

#[tokio::test]
async fn independent_instances_progress() {
    let (first, directory) = records();
    let (second, other_directory) = records();
    let first = Arc::new(first);
    let probe = first.worker.probe.clone();
    let (gate, watchdog) = super::super::physical_tests::hold(probe.clone());
    *probe.before.lock().unwrap() = Some(gate);
    let worker = first.clone();
    let held = tokio::spawn(async move { worker.store_secret(Uuid::new_v4(), &secret()).await });
    super::super::physical_tests::reached(&probe.started, 1).await;
    assert_eq!(
        second.store_secret(Uuid::new_v4(), &secret()).await,
        Ok(Publication::Acknowledged)
    );
    assert_eq!(probe.cleaned.load(std::sync::atomic::Ordering::SeqCst), 0);
    held.await.unwrap().unwrap();
    assert_eq!(watchdog.join().unwrap(), (1, 1, 0));
    let _ = std::fs::remove_dir_all(directory);
    let _ = std::fs::remove_dir_all(other_directory);
}

#[test]
fn no_runtime_first_poll_is_typed() {
    let (records, directory) = records();
    let server = Uuid::new_v4();
    let auth = ServerAuth::consent_needed(server, "docs", "https://mcp.example/mcp");
    let run = super::super::physical_tests::plain_thread;
    assert!(matches!(run(records.load(server)), Err(RecordFailure::Unavailable)));
    assert_eq!(super::super::physical_tests::plain_thread(records.store(&auth)), Err(RecordFailure::Unavailable));
    assert!(super::super::physical_tests::plain_thread(records.load_secret(server)) == Err(RecordFailure::Unavailable));
    assert_eq!(super::super::physical_tests::plain_thread(records.store_secret(server, &secret())), Err(RecordFailure::Unavailable));
    assert_eq!(super::super::physical_tests::plain_thread(records.delete_secret(server)), Err(RecordFailure::Unavailable));
    assert_eq!(records.worker.probe.submitted.load(std::sync::atomic::Ordering::SeqCst), 0);
    assert!(!directory.exists());
}

#[test]
fn queued_send_future_resumes_on_plain_thread() {
    let (records, directory) = records();
    let records = Arc::new(records);
    let server = Uuid::new_v4();
    let probe = records.worker.probe.clone();
    let (gate, watchdog) = super::super::physical_tests::hold(probe.clone());
    *probe.before.lock().unwrap() = Some(gate);
    let runtime = tokio::runtime::Builder::new_current_thread().enable_time().build().unwrap();
    let first = records.clone();
    let held = runtime.block_on(async {
        let held = tokio::spawn(async move { first.store_secret(server, &secret()).await });
        super::super::physical_tests::reached(&probe.started, 1).await;
        held
    });
    let later = records.clone();
    let mut future = Box::pin(async move { later.load_secret(server).await });
    runtime.block_on(std::future::poll_fn(|context| {
        assert!(future.as_mut().poll(context).is_pending());
        std::task::Poll::Ready(())
    }));
    let result = std::thread::spawn(move || super::super::physical_tests::plain_thread(future)).join().unwrap();
    assert!(result.unwrap() == Some(secret()));
    runtime.block_on(held).unwrap().unwrap();
    assert_eq!(watchdog.join().unwrap(), (1, 1, 0));
    let _ = std::fs::remove_dir_all(directory);
}

#[test]
#[ignore = "manual local composed OAuth benchmark; scripted HTTP/callbacks, raw CSV"]
fn benchmark_scripted_authorize_callback_refresh() {
    use crate::mcp_authorization::application::{AuthorizationOwner, AuthorizeAnswer, CallbackQuery, OAuthResponse};
    use crate::mcp_authorization::infrastructure::{FileAuthorizationAudit, MemoryAuthorization, ScriptedCallback};
    use std::time::Instant;
    let output = std::env::var("NESSA_627_BENCH_OUT").unwrap_or_else(|_| "/tmp/627-oauth-worker.csv".into());
    let samples: usize = std::env::var("NESSA_627_BENCH_SAMPLES").ok().map(|value| value.parse().unwrap()).unwrap_or(1000);
    let runtime = tokio::runtime::Builder::new_multi_thread().worker_threads(2).max_blocking_threads(8).enable_time().build().unwrap();
    let directory = tempfile::tempdir().unwrap();
    let rows = runtime.block_on(async {
        let mut lanes = Vec::new();
        for lane in 0..4 {
            let path = directory.path().join(format!("lane-{lane}"));
            let records = Arc::new(FileRecords::new(path.join("records")));
            let audit = Arc::new(FileAuthorizationAudit::new(path.join("audit.jsonl")));
            let memory = Arc::new(MemoryAuthorization::new());
            let owner = Arc::new(AuthorizationOwner::new(records, audit, memory.clone(), Arc::new(ScriptedCallback::pending()), memory.clone(), memory.clone(), memory.clone(), memory.clone(), true));
            lanes.push(tokio::spawn(async move {
                let mut rows = Vec::new();
                // Ten discarded complete workflows warm each independent lane.
                for sample in 0..(samples / 4 + 10) {
                    let server = Uuid::new_v4();
                    memory.set_resource(server, "https://mcp.example/mcp").await;
                    let response = |status, body: &str| OAuthResponse { status, body: body.into(), www_authenticate: None };
                    memory.push_route("https://mcp.example/mcp", Ok(OAuthResponse { status: 401, body: String::new(), www_authenticate: Some("Bearer resource_metadata=\"https://mcp.example/.well-known/oauth-protected-resource\"".into()) })).await;
                    memory.push_route("https://mcp.example/.well-known/oauth-protected-resource", Ok(response(200, r#"{"resource":"https://mcp.example/mcp","authorization_servers":["https://as.example"],"scopes_supported":["mcp"]}"#))).await;
                    memory.push_route("https://as.example/.well-known/oauth-authorization-server", Ok(response(200, r#"{"issuer":"https://as.example","authorization_endpoint":"https://as.example/authorize","token_endpoint":"https://as.example/token","registration_endpoint":"https://as.example/register","revocation_endpoint":"https://as.example/revoke","code_challenge_methods_supported":["S256"]}"#))).await;
                    memory.push_route("https://as.example/register", Ok(response(201, r#"{"client_id":"client"}"#))).await;
                    memory.push_route("https://as.example/token", Ok(response(200, r#"{"access_token":"bench-access","refresh_token":"bench-refresh","expires_in":60}"#))).await;
                    memory.push_route("https://as.example/token", Ok(response(200, r#"{"access_token":"bench-replacement","refresh_token":"bench-refresh","expires_in":60}"#))).await;
                    let start = Instant::now();
                    let answer = owner.authorize(server, "docs", "https://mcp.example/mcp").await;
                    let AuthorizeAnswer::PendingConsent { consent_url, .. } = answer else { panic!("scripted consent failed: {answer:?}"); };
                    let state = consent_url.split("state=").nth(1).unwrap().split('&').next().unwrap().to_owned();
                    assert!(matches!(owner.complete_callback(server, CallbackQuery { state, code: Some("code".into()), denied: false }).await, AuthorizeAnswer::Ready { generation: 1 }));
                    assert_eq!(owner.bearer(server).await.unwrap().unwrap().generation, 1);
                    assert_eq!(owner.rejected(server, "Bearer").await.unwrap().unwrap().generation, 2);
                    if sample >= 10 { rows.push((lane, sample - 10, start.elapsed().as_nanos())); }
                }
                rows
            }));
        }
        let mut rows = Vec::new();
        for lane in lanes { rows.extend(lane.await.unwrap()); }
        rows
    });
    let mut raw = std::fs::File::create(output).unwrap();
    writeln!(raw, "record_instances,audit_instances,concurrency,scripted_network_ms,operation,lane,sample,elapsed_ns").unwrap();
    for (lane, sample, elapsed) in rows { writeln!(raw, "4,4,4,0,authorize_callback_bearer_refresh,{lane},{sample},{elapsed}").unwrap(); }
    for lane in 0..4 {
        let lines = std::fs::read_to_string(directory.path().join(format!("lane-{lane}/audit.jsonl"))).unwrap();
        assert!(lines.lines().all(|line| serde_json::from_str::<serde_json::Value>(line).is_ok()));
        assert!(!contains_token(directory.path(), "bench-access"));
        assert!(!contains_token(directory.path(), "bench-replacement"));
    }
}
