# Bounded physical persistence (#627)

Scope: SqliteOwnershipStore, FileRecords (all five combined-port methods), and
FileAuthorizationAudit. Constructors and disk formats stay unchanged.

```text
async caller -> await one instance slot -> clone owned input -> submit blocking job
                                                job owns input/state then permit
caller drop ----------------------------------> job continues through physical I/O
                                                and owned cleanup -> release slot
next same-instance caller -> waits ------------------------------------^ 
```

Admission precedes large clones and blocking submission. The owned job holds its
permit through operation, input, state and local guard destruction. This is an
instance boundary, not a global/path lock or a shutdown-drain API. SQLite read
returns empty only for NoRows. Interrupted write returns Uncertain; interrupted
secret publication/deletion returns Unknown; read interruption is unavailable.
Audit retains its two writes: interruption can leave a partial line.
Coordinator revision and settlement authority remain in application/domain code.

| # | Ordering | Required result | Proposed named test |
|---|---|---|---|
| 1 | Current-thread runtime; ownership write held in actual adapter before SQLite effect | Independent heartbeat/timer advances while write remains held. | ownership_write_keeps_current_thread_heartbeat_running |
| 2 | Same for ownership read held at query/decode | Heartbeat advances; read result remains pending then validates real snapshot. | ownership_read_keeps_current_thread_heartbeat_running |
| 3 | FileRecords nonsecret load/store held at actual file helper | Heartbeat advances; actual JSON/durability path resumes and completes. | record_io_keeps_current_thread_heartbeat_running |
| 4 | FileRecords secret load/store/delete held at physical helper | Heartbeat advances; actual sealing/file/delete operation resumes with existing typed result. | secret_io_keeps_current_thread_heartbeat_running |
| 5 | FileAuthorizationAudit held at actual append/sync helper | Heartbeat advances; real secret-free record appended only after gate release. | authorization_audit_keeps_current_thread_heartbeat_running |
| 6 | A holds instance worker; B/C wait async admission | Only A submitted/started; no growing blocking jobs; heartbeat continues. | instance_admission_limits_submitted_workers |
| 7 | B canceled while waiting admission | B creates no worker/effect; A completes; next waiter can admit. | canceled_admission_starts_no_worker |
| 8 | A admitted and queued in blocking pool; A caller drops before closure starts | A still owns slot; B cannot start; A executes once when pool permits. | queued_canceled_worker_retains_slot |
| 9 | A executing actual SQLite write; caller drops; B write/read arrives | Permit remains held; B starts only after A physical completion; final snapshot order follows existing coordinator fence. | canceled_sqlite_write_excludes_following_io |
|10 | A executing secret write; caller drops; delete/load/replacement arrives | All same-instance operations excluded until A ends; no late old publication after the later delete/replacement. | canceled_secret_store_excludes_delete_and_load |
|11 | A executing delete; caller drops; replacement secret write arrives | Replacement waits for actual delete completion, then publishes; old delete cannot later remove replacement. | canceled_delete_excludes_replacement |
|12 | Audit A caller drops mid append; audit B arrives | B waits until A physical append/sync ends; successful appends retain existing order and secret-free fields; interruption may leave partial bytes and is reported as failure. | canceled_audit_excludes_next_append |
|13 | Worker panics before effect | Typed conservative method outcome; permit eventually available; no fake absence/acknowledgement. | pre_effect_worker_panic_is_typed |
|14 | Worker executes write/publish/delete/append then panics | Ownership Uncertain; secret Unknown; delete Unknown; audit failure; recovery/load observes actual disk outcome. | landed_effect_worker_panic_is_uncertain |
|15 | Disk/read/decode/lock-poison failure | Correct typed failure; no empty snapshot/None invented; no runtime-thread lock wait. | storage_read_decode_and_poison_are_typed |
|16 | Ownership newer revision publishes before older snapshot reaches coordinator fence | Existing fence skips old copy; worker adapter does not bypass/duplicate fence. | coordinator_revision_fence_skips_stale_snapshot |
|17 | Adapter instance A held; independent instance B/directory operation | B can progress; no new global lock/serialization guarantee. | independent_instances_progress |
|18 | Panic/caller disappearance while worker state/input/future cleanup is still physical work | Permit covers worker completion; later operation never starts merely because its original waiter exited. | worker_input_drop_keeps_slot |
|19 | Port future first polled without a Tokio context | Typed pre-effect unavailability; constructor does not need a runtime; no panic/effect/worker submission. | no_runtime_first_poll_is_typed |
|20 | Send port future starts waiting for admission in Tokio and resumes on an ordinary thread | Admission carries its originating executor; live originating runtime executes the physical job and caller observes actual result. | queued_send_future_resumes_on_plain_thread |
|21 | Originating executor shuts down after admission began | No promise of runtime-independent completion; failed join stays typed conservative unavailability/uncertainty. | originating_runtime_shutdown_is_typed |


## Local evidence and measurement scope

The first red source was dirty over f1682e8a763646c6c3e73dee73c1c47987e2cbae:
test-only gates and five representative tests, with production still inline.
Independent OS watchdogs released real storage operations after sampling the
current-thread heartbeat immediately before release. All five reported 1 -> 1.
The initial files and tracked patch are archived in /tmp/627-red-checkpoint,
including hashes and precise Cargo/direct-binary provenance. No clean red commit
is claimed. The initial worker implementation passes those same five tests.
Extended matrices, mutation results and benchmark results are recorded separately.

The current graph has a global 128 retained-request cap. The manual SQLite
benchmark therefore measures legal single-store 32/256/2048 root-lifetime rows,
with zero spawns, and separately closed-root history and an empty snapshot.
Fixtures verify domain restoration. CSV records actual lifetime/spawn/settlement/
report/live counts, encoded body bytes, one adapter instance, concurrency and raw
end-to-end nanoseconds. It does not claim 2048 retained reservations. Measurements
are local filesystem/runtime results, not production latency or network timings.
