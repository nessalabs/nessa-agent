import os,pathlib,subprocess,json,time,glob,sys
root=pathlib.Path('/workspace/nessa-agent-bounded-persistence')
out=pathlib.Path('/tmp/627-corrected-final-gates');out.mkdir(exist_ok=True)
env=dict(os.environ,CARGO_HOME='/tmp/nessa-cargo',RUSTUP_HOME='/tmp/nessa-rustup',PATH='/tmp/nessa-tools/bin:/tmp/nessa-cargo/bin:'+os.environ['PATH'],CARGO_TARGET_DIR='/workspace/nessa-agent/target',CARGO_NET_OFFLINE='true',CARGO_BUILD_JOBS='2',CARGO_INCREMENTAL='0')
packages=['-p','nessa-local-storage','-p','nessa-auth','-p','nessa-server','-p','nessa-protocol','-p','nessa-client-core','-p','nessa-sdk']
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
if subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip():raise SystemExit('Dirty source: refused')
gates=[('format',['cargo','fmt']+packages+['--','--check']),('sdk-ownership-matrix',['cargo','test','-p','nessa-sdk','--lib','infrastructure::session_storage::ownership::tests','--','--nocapture']),('ci-six-package-clippy',['cargo','clippy']+packages+['--all-targets','--','-D','warnings']),('sdk-docs',['node','scripts/check-sdk-docs.mjs']),('architecture-tests',['node','--test']+sorted(glob.glob(str(root/'scripts/architecture/*.test.mjs')))),('architecture',['node','scripts/check-architecture.mjs']),('frontend-format',['pnpm','format:check']),('frontend-scripts',['pnpm','scripts:test'])]
source_path=root/'verification/bounded-persistence/evidence/consolidated/candidate-source-sha256.json'
source_hashes=json.loads(source_path.read_text())
import hashlib
assert all((hashlib.sha256((root/p).read_bytes()).hexdigest() if (root/p).is_file() else None)==expected for p,expected in source_hashes.items())
manifest={'base':'d55de88d9c6f5794b225da05b1055c511b9dba74','source_hashes':source_hashes,'head':head,'environment':{k:env[k] for k in ['CARGO_HOME','RUSTUP_HOME','CARGO_TARGET_DIR','CARGO_NET_OFFLINE','CARGO_BUILD_JOBS','CARGO_INCREMENTAL','PATH']},'gates':[]}
manifest['original_209_gate_manifest']='/tmp/627-consolidated-final-gates/manifest.json'
manifest['source_change_since_209']='Only cfg(test) held-admission fixture .ok().expect -> .expect; original full suites remain original-head proof, hosted CI reruns full suites at this head.'
for name,cmd in gates:
 if subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()!=head or subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip():raise SystemExit('Source changed: stopped')
 assert all((hashlib.sha256((root/p).read_bytes()).hexdigest() if (root/p).is_file() else None)==expected for p,expected in source_hashes.items())
 cmd=['/tmp/nessa-browser-libs/usr/bin/tini','-s','--']+cmd
 started=time.monotonic();print('START',name,flush=True)
 with (out/(name+'.log')).open('w') as log: result=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 row={'name':name,'command':cmd,'exit_code':result.returncode,'seconds':round(time.monotonic()-started,2),'log':str(out/(name+'.log'))}
 manifest['gates'].append(row);(out/'manifest.json').write_text(json.dumps(manifest,indent=2));print('END',name,result.returncode,row['seconds'],flush=True)
 if result.returncode:sys.exit(result.returncode)
 if name=='local-storage-default-normal-tree':
  assert 'tokio v' not in (out/(name+'.log')).read_text(), 'Default-off normal tree unexpectedly contains Tokio'
 if name=='ci-six-package-tests':
  mapping=json.loads((root/'verification/bounded-persistence/evidence/consolidated/central-ci-test-names.json').read_text())
  content=(out/(name+'.log')).read_text()
  presence={test:('physical_operation::tests::'+test+' ... ok') in content for test in mapping}
  (out/'central-ci-presence.json').write_text(json.dumps(presence,indent=2)+'\n')
  assert all(presence.values()), 'Combined CI did not execute every central physical_operation case'

