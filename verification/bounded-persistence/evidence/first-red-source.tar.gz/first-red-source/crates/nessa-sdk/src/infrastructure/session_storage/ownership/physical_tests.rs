//! Physical-operation gates with an independent wall-clock watchdog.
use std::future::Future;
use std::sync::{atomic::{AtomicUsize, Ordering}, mpsc, Arc, Mutex};
use std::time::Duration;

pub(super) struct Gate {
    entered: mpsc::Sender<()>,
    release: Mutex<mpsc::Receiver<()>>,
}
impl Gate {
    pub(super) fn enter(&self) {
        self.entered.send(()).unwrap();
        self.release.lock().unwrap().recv_timeout(Duration::from_secs(5)).unwrap();
    }
}

pub(super) fn heartbeat<F, Fut>(operation: F)
where F: FnOnce(Arc<Gate>) -> Fut, Fut: Future<Output = ()> {
    let (entered_tx, entered_rx) = mpsc::channel();
    let (release_tx, release_rx) = mpsc::channel();
    let gate = Arc::new(Gate { entered: entered_tx, release: Mutex::new(release_rx) });
    let ticks = Arc::new(AtomicUsize::new(0));
    let observed = ticks.clone();
    let watchdog = std::thread::spawn(move || {
        entered_rx.recv_timeout(Duration::from_secs(5)).unwrap();
        let before = observed.load(Ordering::SeqCst);
        std::thread::sleep(Duration::from_millis(120));
        let after = observed.load(Ordering::SeqCst);
        release_tx.send(()).unwrap();
        (before, after)
    });
    tokio::runtime::Builder::new_current_thread().enable_time().build().unwrap().block_on(async {
        let heartbeat = tokio::spawn(async move {
            loop {
                ticks.fetch_add(1, Ordering::SeqCst);
                tokio::time::sleep(Duration::from_millis(2)).await;
            }
        });
        tokio::task::yield_now().await;
        operation(gate).await;
        heartbeat.abort();
        let _ = heartbeat.await;
    });
    let (before, after) = watchdog.join().unwrap();
    assert!(after > before, "current-thread heartbeat froze during physical I/O: {before} -> {after}");
}
