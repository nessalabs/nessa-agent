First RED used dirty source over f1682e8a763646c6c3e73dee73c1c47987e2cbae.
Tracked changes are tracked.patch; untracked gate files and design are preserved
here byte-for-byte before they were extended. There was no clean RED commit.
Reconstruction: apply tracked.patch to that base; install sdk-physical-tests.rs
at crates/nessa-sdk/src/infrastructure/session_storage/ownership/physical_tests.rs,
server-physical-tests.rs at crates/nessa-server/src/mcp_authorization/infrastructure/physical_tests.rs,
and design.md at docs/design/bounded-physical-persistence.md.

Original Cargo SDK+server command compiled both packages, then ran SDK's two
RED tests and stopped on that crate failure (/tmp/627-first-red.log).
While server compile was finishing, SDK's newly built binary was also executed
directly (/tmp/627-sdk-first-red-direct.log). Separate Cargo server invocation
ran three RED tests (/tmp/627-server-first-red.log). Both SDK invocations used
the same unchanged test-only dirty source and reported heartbeat 1 -> 1.
First GREEN later changed production source; /tmp/627-first-green.log contains
five passing representative heartbeat tests, not an assertion about RED source.
